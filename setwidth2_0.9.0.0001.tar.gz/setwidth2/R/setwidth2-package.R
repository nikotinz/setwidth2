#' @title Automatically set the value of options("width") when the terminal
#'   emulator is resized
#' @name setwidth2-package
#' @aliases setwidth-package setwidth2
#' @docType package
#' @description
#' Inspired by and based on the original 'setwidth' package by Jakson Alves de
#' Aquino, but extended for cross-platform support (Linux, macOS, Windows).
#' For best experience, it is recommended to have the 'later' package installed
#' (used for event handling and timer fallback).
#' This package should not be used with Graphical User Interfaces, such as
#' Windows RGui, RStudio, RKward, JGR, Rcmdr and other interfaces which have
#' their own engine to display R output. The functions of this package only
#' work if R is compiled for Linux, macOS, or Windows systems and it is running
#' interactively in a terminal emulator. The terminal emulator might have been
#' called by a text editor, such as Vim, Gedit, Kate or Geany.
#'
#' @details
#' The package will print information on the R Console if its
#' `setwidth2.verbose` option was set to a numeric value bigger than zero:
#'
#' \preformatted{
#' options(setwidth2.verbose = 1) # Print startup message
#' options(setwidth2.verbose = 2) # Print error message when unable to set width
#' options(setwidth2.verbose = 3) # Print width value
#' }
#'
#' The package does not have any user visible R function. When it is loaded,
#' a platform-specific event handler in C is installed to update
#' `options("width")` whenever the terminal size changes. The handler is only
#' activated if R is running interactively and the terminal environment is
#' suitable (e.g., `interactive() == TRUE` and the `TERM` environment variable
#' is not empty or set to `"dumb"`).
#'
#' On Unix-like systems (Linux/macOS), the width is updated by polling the
#' terminal size using the event loop (if available) or by using a timer
#' fallback. On Windows, a timer is used to periodically check the console
#' width.
#'
#' To manually test whether the package is working properly on your system you 
#' may repeatedly resize the terminal emulator and print a long vector, like 
#' 1:300.
#'
#' To disable the automatic setting of `options("width")` do:
#'
#' \preformatted{
#' detach("package:setwidth2", unload = TRUE)
#' }
#'
#' @author Jakson Alves de Aquino, Dominique-Laurent Couturier, Nikita
#'   Mozgunov with some code copied from Vim.
#' @seealso \code{colorout} package colorizes R output when running in a
#'   terminal emulator.
#' @examples
#' options(setwidth2.verbose = 1)
#' print(getOption("width"))
#' @useDynLib setwidth2, .registration = TRUE
#' @exportPattern ^
"_PACKAGE"
